package com.cap.exception;

public class BankException extends Exception {
	public BankException() {
		
	}
	public BankException(String str) {
		super(str);
	}

	
}
       